const express = require('express');
const cors = require('cors')
const app = express();
const port = 3000;

app.use(express.json());
app.use(cors())


app.listen(port, () => console.log(`Rodando na porta ${port}`));

const connection = require('./db_config.js');

app.post('/usuarios/cadastrar', (request, response) => {
    let params = [
        request.body.Nome,
        request.body.Telefone,
        request.body.Aniversario,
        request.body.Email,
        request.body.Senha
    ]

    let query = "INSERT INTO usuariosCadastrar(nome, telefone, aniversario, email, senha) VALUES (?, ?, ?, ?, ?);"
    connection.query(query, params, (err, results) => {
        if (results) {
            response.status(201).json({
                success: true,
                message: "Sucesso",
                data: results
            });
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "Sem sucesso",
                    date: err
                });
        }
    });
});


app.post('/usuarios/logar', (request, response) => {
    let { Email, Senha } = request.body;
    let params = [
        request.body.Email,
        request.body.Senha
    ]

    let query = "SELECT * FROM usuariosCadastrar WHERE email = ? AND senha = ?;";
    connection.query(query, params, (err, results) => {
    if (err) {
        return response.status(500).json({
            success: false,
            message: "Erro no servidor",
            error: err
        });
    }

    if (results.length > 0) {
        return response.status(200).json({
            success: true,
            message: "Login bem-sucedido",
            data: results
        });
    } else {
        return response.status(401).json({
            success: false,
            message: "Email ou senha incorretos"
        });
    }
});
}); 


app.get('/usuarios/listar', (request, response) => {
    let query = "SELECT * FROM usuariosCadastrar";
    connection.query(query, (err, results) => {
        if (results) {
            response.status(201).json({
                success: true,
                message: "Sucesso",
                data: results
            });
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "Sem sucesso",
                    data: err
                });
        }
    });
});

app.put('/usuarios/editar/:id', (request, response) => {
    let params = Array(
        request.body.Nome,
        request.body.Telefone,
        request.body.Aniversario,
        request.body.Email,
        request.body.Senha
    )

    let query = "UPDATE usuariosCadastrar SET email = (?), senha = (?)";
    connection.query(query, params, (err, results) => {
        if (results) {
            response.status(201).json({
                success: true,
                message: "Sucesso",
                data: results
            });
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "Sem sucesso",
                    data: err
                });
        }
    });
});

app.delete('/usuarios/deletar/:id', (request, response) => {
    let query = "DELETE FROM usuariosCadastrar WHERE id = ?";
    connection.query(query, [request.params.id], (err, results) => {
        if (err) {
            response
                .status(400)
                .json({
                    success: false,
                    message: "Erro ao deletar usuário",
                    error: err
                });
        } else {
            if (results.affectedRows > 0) {
                response.status(200).json({
                    success: true,
                    message: "Usuário deletado",
                    data: results
                });
            } else {
                response.status(404).json({
                    success: false,
                    message: "Usuário não encontrado"
                });
            }
        }
    });
});
