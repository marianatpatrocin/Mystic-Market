async function cadastrar (event) {
    event.preventDefault();
    
    const Nome = document.getElementById('nome').value;
    const Telefone = document.getElementById('telefone').value;
    const Aniversario = document.getElementById('aniversario').value;
    const Email= document.getElementById('email').value;
    const Senha = document.getElementById('senha').value;

    const data = {Nome, Telefone, Aniversario, Email, Senha}

    console.log("Data:", data)

    const response = await fetch('http://localhost:3000/usuarios/cadastrar', {
        method: "POST", 
        headers: {
            "Content-Type":"application/json"
        },
        body: JSON.stringify(data)
    })

    const results = await response.json("Response:", results);

    if(results.success) {
        alert(results.message)
    } else {
        alert(results.message)
    }
}